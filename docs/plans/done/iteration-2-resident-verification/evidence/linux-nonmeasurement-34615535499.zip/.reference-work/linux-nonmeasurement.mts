import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { resolve } from 'node:path';
          import { executionIdentity } from '../scripts/reference-harness/artifact.js';
import { plan2Instances } from '../scripts/reference-harness/plan2-instances.js';
import { verifyPlan1Regression } from '../scripts/reference-harness/completion-regression.js';
import { evidenceRoots, portableValue } from '../scripts/reference-harness/portability.js';
import { readReviewedPlan2, repositoryRoot, validateInstancePointers } from '../scripts/reference-harness/plan.js';
import { plan2Runtime } from '../scripts/reference-harness/plan2-runtime.js';
import { verifyInstances } from '../scripts/reference-harness/runner.js';

async function runNonmeasurement(output: string) {
  assert.equal(process.platform, 'linux');
  const prerequisite = await verifyPlan1Regression();
  await writeFile('plan2-linux-plan1-consumed.json', JSON.stringify(prerequisite));
  const plan = readReviewedPlan2();
  const members = plan.members.filter(member => member[9]?.evidence !== 'measurement');
  const selectedIds = members.map(member => member[0]);
  assert.equal(selectedIds.length, 167);
  const ids = new Set(selectedIds);
  const records = plan2Instances.filter(item => ids.has(item.id));
  assert.equal(records.length, 167);
  assert.deepEqual(validateInstancePointers(records), []);
  const endpoint = await mkdtemp('/tmp/rl2n-');
  const previousEndpoint = process.env.RAMIFY_ENDPOINT_DIR;
  process.env.RAMIFY_ENDPOINT_DIR = endpoint;
  const identity = await executionIdentity();
  const startedAt = new Date().toISOString(), started = performance.now();
  const execute = (args: string[]) => new Promise<{ code: number | null; stdout: string; stderr: string }>((resolveRun, reject) => {
    const child = spawn(process.execPath, ['dist/src/cli-entry.js', ...args], { cwd: repositoryRoot, env: process.env, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '', stderr = '';
    child.stdout.on('data', bytes => stdout += bytes); child.stderr.on('data', bytes => stderr += bytes);
    child.once('error', reject); child.once('close', code => resolveRun({ code, stdout, stderr }));
  });
  let report, stop, status;
  try {
    report = await verifyInstances({ plan: { ...plan, members }, records,
      runtime: plan2Runtime, workRoot: resolve(repositoryRoot, 'examples/collection-review/.reference-work'), preserveOnFailure: true });
  } finally {
    stop = await execute(['daemon', 'stop']); status = await execute(['daemon', 'status', '--format', 'json']);
    await writeFile('plan2-linux-cleanup.json', JSON.stringify({ endpoint, stop, status }));
  if (stop.code === 0) await rm(endpoint, { recursive: true, force: true });
    if (previousEndpoint === undefined) delete process.env.RAMIFY_ENDPOINT_DIR; else process.env.RAMIFY_ENDPOINT_DIR = previousEndpoint;
  }
  const after = await executionIdentity();
  assert.equal(after.sourceSha256, identity.sourceSha256, 'Source changed during focused execution');
  assert.equal(after.buildSha256, identity.buildSha256, 'Build changed during focused execution');
  const artifact = portableValue({ kind: 'linux-plan2-nonmeasurement-evidence', identity, platform: process.platform, selectedIds,
    startedAt, completedAt: new Date().toISOString(), durationMs: performance.now() - started,
    report: { ...report, planComplete: false }, cleanup: { stop, status } }, await evidenceRoots());
  await writeFile(output, JSON.stringify(artifact) + '\n', { flag: 'wx' });
  assert.equal(stop.code, 0); assert.equal(status.code, 0); assert.equal(JSON.parse(status.stdout).running, false);
  assert.equal(report?.passed, true, JSON.stringify(report?.instances.filter(item => item.status !== 'passed')));
  return artifact;
}

const result = await runNonmeasurement('plan2-linux-nonmeasurement.json');
console.log(JSON.stringify({ summary: result.report.summary, identity: result.identity, durationMs: result.durationMs }));
